########################################################

              _______  ___ _______ ____
             / __/ _ \(_-</ __/ _ `/ _ \.
             \__/ .__/___/\__/\_,_/_//_/
               /_/ v 1.0 - susmithHCK

########################################################

cpscan is a simple admin panel finder coded in python. 
The script actually bruteforce the possible directories and returns the HTTP response code.
you can add your own directories by editing "dir" file.

USAGE:

         -t  --target   - Target web server "example.com"
         -v  --verbose  - Enable verbose mode
         -h  --help     - show this menu

EXAMPLE:

          python cpscan.py -t targetsite.com -v
			   
if you have any suggestions please contact me 	https://www.facebook.com/Susmith.AfRo
